import React from 'react';
import LoginForm from '../components/LoginForm';
import Link from 'next/link';

const LoginPage: React.FC = () => {

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <div className='ml-4 mt-4'>
        <Link href='/'><button className="w-32 p-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 mb-6">Go Back</button></Link>
      </div>
      <div className='m-auto w-2/5'>
        <LoginForm />
      </div>
    </div>
  );
};

export default LoginPage;
