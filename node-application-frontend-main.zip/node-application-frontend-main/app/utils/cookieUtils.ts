export const getCookie = (name: string): string | null => {
  const matches = document.cookie.match(new RegExp(
      `(?:^|; )${name.replace(/([.$?*|{}()[]\/+^])/g, '\\$1')}=([^;]*)`
  ))
  return matches ? decodeURIComponent(matches[1]) : null
}

export const setCookie = (name: string, value: string, options: { [key: string]: unknown } = {}) => {
  let cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`
  for (const [key, val] of Object.entries(options)) {
      cookie += `; ${key}=${val}`
  }
  document.cookie = cookie
}

export const clearTokenCookie = () => {
  document.cookie = 'token=; path=/; max-age=0; SameSite=Strict';
};
