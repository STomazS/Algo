export enum Path {
    USERS,
    LOGIN,
    REGISTER,
    EXPENSES,
    HOME,
    CONFIRM_ACCOUNT
}

export function getPath(path: Path){
    switch (path){
        case Path.CONFIRM_ACCOUNT: return '/confirmaccount'
        case Path.EXPENSES: return '/expenses'
        case Path.HOME: return '/home'
        case Path.LOGIN: return '/login'
        case Path.REGISTER: return '/register'
        case Path.USERS: return '/users'
    }
}

export function getPathName(path: Path){
    switch (path){
        case Path.CONFIRM_ACCOUNT: return 'Confirm Account'
        case Path.EXPENSES: return 'Expenses'
        case Path.HOME: return 'Home'
        case Path.LOGIN: return 'Login'
        case Path.REGISTER: return 'Register'
        case Path.USERS: return 'Users'
    }
}