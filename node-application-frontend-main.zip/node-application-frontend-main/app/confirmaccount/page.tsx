import React from 'react'
import ConfirmAccountForm from '../components/ConfirmAccountForm';
import Link from 'next/link';

const ConfirmAccount = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <div className='ml-4 mt-4'>
        <Link href='/'><button className="w-32 p-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 mb-6">Go Back</button></Link>
      </div>
      <div className='m-auto w-2/5'>
        <ConfirmAccountForm></ConfirmAccountForm>
      </div>
    </div>
  )
}

export default ConfirmAccount