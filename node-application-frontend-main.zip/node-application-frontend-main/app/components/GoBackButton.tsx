'use client'

import React from 'react'

const GoBackButton = () => {

    function goBack() {
        window.history.back()
    }

  return (
    <button className="w-32 p-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 mb-6" onClick={goBack}>Go Back</button>
  )
}

export default GoBackButton