'use client'

import React, { useState } from 'react'
import HashRoutes from '../api/hash'
import { Path } from '../utils/path'
import AuthButton from './AuthButton'

const ConfirmAccountForm = () => {
    const [email, setEmail] = useState('')
    const [code, setCode] = useState('')
    const [errorMessage, setErrorMessage] = useState('')
    const [confirmed, setConfirmed] = useState(false)

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault()

        if (!code) {
            setErrorMessage('Please fill code field!')
            return
        }

        setErrorMessage('')

        HashRoutes.confirmAccount(email, code)
            .then((result) => {
                if (result.status === 200) {
                    setConfirmed(true);
                } else {
                    setErrorMessage('Invalid code and email combination!');
                }
            })
            .catch((error) => {
                setErrorMessage('An error occurred, please try again later.');
                console.log(error);
            });

    }

    return (<div>
        {confirmed ? (
            <div><h1 className='text-4xl text-center mb-12'>Account has been Confirmed!</h1><div className='mb-44'><AuthButton path={Path.LOGIN}></AuthButton></div></div>
    ) : (
        <><form onSubmit={handleSubmit} className="w-full max-w-md p-6 bg-white shadow-md rounded-md">
            <h2 className="text-2xl font-semibold text-center mb-6">Confirm Account</h2>

            <div className="form-field mb-4">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                <input className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" type="email" id='email' value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>

            <div className="form-field mb-4">
                <label htmlFor="code" className="block text-sm font-medium text-gray-700">Code</label>
                <input className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" type="text" id='code' value={code} onChange={(e) => setCode(e.target.value)} required />
            </div>

            {errorMessage && <p className="text-red-500 text-sm mt-2">{errorMessage}</p>}

            <button
                type="submit"
                className="w-full p-3 mt-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
                Verify Code
            </button>
        </form></>
    )
}
    </div >

    )
}

export default ConfirmAccountForm