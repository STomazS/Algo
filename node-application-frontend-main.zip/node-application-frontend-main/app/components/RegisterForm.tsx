'use client'

import React, { useState } from 'react';
import PasswordField from './PasswordField';
import HashRoutes from '../api/hash';
import { useRouter } from 'next/navigation'
import Link from 'next/link';

const RegisterForm = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const router = useRouter();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (password !== confirmPassword) {
            setErrorMessage('Passwords do not match');
            return;
        }

        setErrorMessage('');

        HashRoutes.registerUser(name, email, password).then((result) => {
            if (result.status === 200) {
                router.push('/confirmaccount');
            } else {
                setErrorMessage('Email already exists');
            }
        })
    };

    return (
        <form onSubmit={handleSubmit} className="w-full max-w-md p-6 bg-white shadow-md rounded-md">
            <h2 className="text-2xl font-semibold text-center mb-6">Register</h2>

            <div className="form-field mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
            </div>

            <div className="form-field mb-4">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
            </div>

            <PasswordField
                label="Password"
                value={password}
                onChange={setPassword}
            />

            <PasswordField
                label="Confirm Password"
                value={confirmPassword}
                onChange={setConfirmPassword}
            />

            {errorMessage && <p className="text-red-500 text-sm mt-2">{errorMessage}</p>}

            <button
                type="submit"
                className="w-full p-3 mt-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
                Register
            </button>

            <p className='text-center mt-2'>Already have an account? <Link href='/login' className='text-blue-400'>Enter here!</Link></p>
        </form>
    );
};

export default RegisterForm;
