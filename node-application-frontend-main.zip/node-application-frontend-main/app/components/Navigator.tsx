import Link from 'next/link'
import React from 'react'

const Navigator = () => {
  return (
    <div>
        <ul>
            <Link href="/users">Users</Link>
            <Link href="/expenses">Expenses</Link>
        </ul>
    </div>
  )
}

export default Navigator