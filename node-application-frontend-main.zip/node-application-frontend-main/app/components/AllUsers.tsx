'use client'

import React, { useEffect, useState } from 'react'
import UserRoutes, { User } from '../api/user'
import { getCookie } from '../utils/cookieUtils'

const AllUsers = () => {
    const [allUsers, setAllUsers] = useState<User[] | null>(null)

    useEffect(() => {
        const fetchUserData = async () => {
            const token = await getCookie('token')

            if (token) {
                const userData = await UserRoutes.getUsers(token)
                setAllUsers(userData || [])
            }
        }

        fetchUserData()
    }, [])

    return (<tbody>
        {allUsers?.length ? (
            allUsers.map(user => (
                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700 border-gray-200' key={user.id}>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                </tr>
            ))
        ) : (
            <tr>
                <td colSpan={2}>No users found</td>
            </tr>
        )}
    </tbody>
    )
}

export default AllUsers
