'use client'

import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import dynamic from 'next/dynamic'
import ExpensesRoutes from '../api/expenses'
import GoBackButton from './GoBackButton'
import { getCookie } from '../utils/cookieUtils'

const ExpenseList = dynamic(() => import('../components/ExpenseList'))
const ExpenseForm = dynamic(() => import('../components/ExpenseForm'))

const ExpensesHandler: React.FC = () => {
    const [expenses, setExpenses] = useState<{ id: string; description: string; value: number }[]>([])
    const [token, setToken] = useState<string | null>(null)
    const router = useRouter()

    useEffect(() => {
        const savedToken = getCookie('token')
        setToken(savedToken)

        if (!savedToken) {
            router.push('/login')
        } else {
            fetchExpenses(savedToken)
        }
    }, [router])

    const fetchExpenses = async (token: string) => {
        try {
            const response = await ExpensesRoutes.getExpenses(token)
            const expensesData = await response.json()
            if (Array.isArray(expensesData)) {
                setExpenses(expensesData)
            } else {
                setExpenses([])
            }
        } catch (error) {
            console.error('Error fetching expenses:', error)
            setExpenses([])
        }
    }

    const addExpense = async (description: string, value: number) => {
        try {
            const result = await ExpensesRoutes.addExpense(description, value, token || '')
            const resultJson = await result.json() as { id: string, description: string, value: number }
            setExpenses((prevExpenses) => [
                ...prevExpenses,
                { id: resultJson.id, description: resultJson.description, value: resultJson.value }
            ])
        } catch (error) {
            console.error('Error adding expense:', error)
        }
    }

    const removeExpense = async (id: string) => {
        const result = await ExpensesRoutes.removeExpense(token || '', id)
        if (result.status === 200)
            setExpenses(expenses.filter((expense) => expense.id !== id))
    }

    const editExpense = async (id: string, description: string, value: number) => {
        try {
            const result = await ExpensesRoutes.editExpense(token || '', id, description, value)
            const updatedExpense = await result.json()
            setExpenses(expenses.map((expense) =>
                expense.id === updatedExpense.id
                    ? { ...expense, description: updatedExpense.description, value: updatedExpense.value }
                    : expense
            ))
        } catch (error) {
            console.error('Error editing expense:', error)
        }
    }

    return (
        <div className="main-page container mx-auto px-4 py-8">
            <GoBackButton></GoBackButton>
            <h1 className="text-3xl font-bold text-center mb-6">Expense Tracker</h1>
            <div className="mb-8">
                <ExpenseList expenses={expenses} removeExpense={removeExpense} editExpense={editExpense} />
            </div>
            <div className="mb-8">
                <ExpenseForm onAddExpense={addExpense} />
            </div>
        </div>
    )
}

export default ExpensesHandler
