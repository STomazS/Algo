'use client'

import React, { useState } from 'react';

interface PasswordFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}

const PasswordField: React.FC<PasswordFieldProps> = ({ label, value, onChange, required = true }) => {
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  const togglePasswordVisibility = () => {
    setIsPasswordVisible(!isPasswordVisible);
  };

  return (
    <div className="form-field">
      <label htmlFor="password" className="block text-sm font-medium text-gray-700">{label}</label>
      <div className="relative">
        <input
          id="password"
          type={isPasswordVisible ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
          className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="button"
          onClick={togglePasswordVisibility}
          className="absolute right-2 top-2 text-sm text-gray-500"
        >
          {isPasswordVisible ? 'Hide' : 'Show'}
        </button>
      </div>
    </div>
  );
};

export default PasswordField;
