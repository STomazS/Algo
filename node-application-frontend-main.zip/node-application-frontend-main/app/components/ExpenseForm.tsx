import React, { useState } from 'react';

interface ExpenseFormProps {
  onAddExpense: (description: string, value: number) => void;
}

const ExpenseForm: React.FC<ExpenseFormProps> = ({ onAddExpense }) => {
  const [description, setDescription] = useState('');
  const [value, setValue] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!description || !value) {
      setErrorMessage('Please fill both fields!');
      return;
    }

    const parsedValue = parseFloat(value);

    if (isNaN(parsedValue) || parsedValue <= 0) {
      setErrorMessage('Please enter a valid value greater than 0!');
      return;
    }

    onAddExpense(description, parsedValue);
    setDescription('');
    setValue('');
    setErrorMessage('');
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="w-full max-w-md p-6 bg-white shadow-md rounded-md mx-auto mt-8"
    >
      <h2 className="text-2xl font-semibold text-center mb-6">Expenses</h2>

      <div className="form-field mb-4">
        <label
          htmlFor="description"
          className="block text-sm font-medium text-gray-700"
        >
          Description
        </label>
        <input
          type="text"
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
          className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="form-field mb-4">
        <label
          htmlFor="value"
          className="block text-sm font-medium text-gray-700"
        >
          Value
        </label>
        <input
          type="text"
          id="value"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          required
          className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {errorMessage && (
        <p className="text-red-500 text-sm mt-2">{errorMessage}</p>
      )}

      <button
        type="submit"
        className="w-full p-3 mt-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
      >
        Add
      </button>
    </form>
  );
};

export default ExpenseForm;
