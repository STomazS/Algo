import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt, faEdit } from '@fortawesome/free-solid-svg-icons';

type Expense = {
  id: string;
  value: number;
  description: string;
};

interface ExpenseListProps {
  expenses: Expense[];
  removeExpense: (id: string) => void;
  editExpense: (id: string, description: string, value: number) => void;
}

const ExpenseList: React.FC<ExpenseListProps> = ({ expenses, removeExpense, editExpense }) => {
  const [confirmDelete, setConfirmDelete] = useState<{ id: string | null; show: boolean }>({
    id: null,
    show: false
  });
  const [editMode, setEditMode] = useState<{ id: string | null; description: string; value: string }>({
    id: null,
    description: '',
    value: ''
  });

  const handleDeleteClick = (id: string) => {
    setConfirmDelete({ id, show: true });
  };

  const handleConfirmDelete = () => {
    if (confirmDelete.id) {
      removeExpense(confirmDelete.id);
      setConfirmDelete({ id: null, show: false });
    }
  };

  const handleCancelDelete = () => {
    setConfirmDelete({ id: null, show: false });
  };

  const handleEditClick = (id: string, description: string, value: number) => {
    setEditMode({ id, description, value: value.toString() });
  };

  const handleSaveEdit = () => {
    if (editMode.id) {
      const parsedValue = parseFloat(editMode.value);
      if (!isNaN(parsedValue) && parsedValue > 0) {
        editExpense(editMode.id, editMode.description, parsedValue);
        setEditMode({ id: null, description: '', value: '' });
      }
    }
  };

  const handleCancelEdit = () => {
    setEditMode({ id: null, description: '', value: '' });
  };

  return (
    <div className="overflow-x-auto shadow-md sm:rounded-lg">
      <table className="min-w-full bg-white text-gray-900">
        <thead className="bg-gray-100 text-sm font-semibold text-left text-gray-700 uppercase">
          <tr>
            <th className="px-6 py-3">Description</th>
            <th className="px-6 py-3">Value</th>
            <th className="px-6 py-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {expenses.map((e, index) => (
            <tr
              key={index}
              className={`${
                index % 2 === 0 ? 'bg-gray-50' : 'bg-white'
              } border-b hover:bg-gray-100`}
            >
              <td className="px-6 py-4">
                {editMode.id === e.id ? (
                  <input
                    type="text"
                    value={editMode.description}
                    onChange={(e) => setEditMode({ ...editMode, description: e.target.value })}
                    className="border p-2 text-white"
                  />
                ) : (
                  e.description
                )}
              </td>
              <td className="px-6 py-4">
                {editMode.id === e.id ? (
                  <input
                    type="number"
                    value={editMode.value || ''} // Ensure it's a string or empty string
                    onChange={(e) => setEditMode({ ...editMode, value: e.target.value })}
                    className="border p-2 text-white"
                  />
                ) : (
                  e.value
                )}
              </td>
              <td className="px-6 py-4">
                {editMode.id === e.id ? (
                  <>
                    <button onClick={handleSaveEdit} className="text-green-500 mr-2">Save</button>
                    <button onClick={handleCancelEdit} className="text-gray-500">Cancel</button>
                  </>
                ) : (
                  <>
                    <FontAwesomeIcon
                      icon={faEdit}
                      style={{ cursor: 'pointer', color: 'blue' }}
                      onClick={() => handleEditClick(e.id, e.description, e.value)}
                    />
                    <FontAwesomeIcon
                      icon={faTrashAlt}
                      style={{ cursor: 'pointer', color: 'red', marginLeft: '10px' }}
                      onClick={() => handleDeleteClick(e.id)}
                    />
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {confirmDelete.show && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <div
            style={{
              backgroundColor: 'white',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center'
            }}
          >
            <h3>Are you sure you want to remove this expense?</h3>
            <div>
              <button
                onClick={handleConfirmDelete}
                style={{
                  backgroundColor: '#e53e3e',
                  color: 'white',
                  padding: '10px 20px',
                  borderRadius: '5px',
                  cursor: 'pointer',
                  margin: '5px'
                }}
              >
                Yes, Remove
              </button>
              <button
                onClick={handleCancelDelete}
                style={{
                  backgroundColor: '#edf2f7',
                  color: 'black',
                  padding: '10px 20px',
                  borderRadius: '5px',
                  cursor: 'pointer',
                  margin: '5px'
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseList;
