'use client'

import React, { useEffect, useState } from 'react'
import UserRoutes, { User } from '../api/user'
import { getCookie } from '../utils/cookieUtils' // Import getCookie directly

const UserInformation = () => {
    const [userInformation, setUserInformation] = useState<User | null>(null)
    const [loading, setLoading] = useState<boolean>(true)
    const [error, setError] = useState<string | null>(null)

    useEffect(() => {
        const fetchUserData = async () => {
            const token = getCookie('token')

            if (token) {
                try {
                    const userData = await UserRoutes.getUserInformation(token)
                    setUserInformation(userData!)
                } catch (error) {
                    console.error("Error fetching user data", error)
                    setError("Failed to load user data. Please try again later.")
                } finally {
                    setLoading(false)
                }
            } else {
                setError("No authentication token found.")
                setLoading(false)
            }
        }

        fetchUserData()
    }, [])

    if (loading) {
        return <div className="ml-8 text-xl">Loading...</div>
    }

    if (error) {
        return <div className="ml-8 text-xl text-red-500">{error}</div>
    }

    return (
        <div className="ml-8 text-xl">
            {userInformation ? `Hello ${userInformation.name}!` : 'User not found.'}
        </div>
    )
}

export default UserInformation
