'use client' // Ensure this is a client-side component

import { useRouter } from 'next/navigation'
import React, { useEffect, useState } from 'react'
import { clearTokenCookie } from '../utils/cookieUtils';

const LogoutButton = () => {
    const [isClient, setIsClient] = useState(false)
    const router = useRouter()

    useEffect(() => {
        setIsClient(true)
    }, []);

    const logout = () => {
        clearTokenCookie();
        router.push('/');
    };

    if (!isClient) return null

    return (
        <button
            className="w-32 p-3 mt-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            onClick={logout}
        >
            Logout
        </button>
    );
};

export default LogoutButton;
