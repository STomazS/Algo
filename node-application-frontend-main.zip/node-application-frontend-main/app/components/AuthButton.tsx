'use client'

import Link from 'next/link';
import React from 'react'
import { getPath, getPathName, Path } from '../utils/path';

interface AuthButtonProps {
    path: Path;
}

const AuthButton: React.FC<AuthButtonProps> = ({ path }) => {
    return (
        <div className="flex justify-center mt-4">
            <Link href={getPath(path)}>
                <button
                    className="w-full sm:w-80 py-3 px-6 text-lg font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300"
                >
                    {getPathName(path)}
                </button>
            </Link>
        </div>
    );
}

export default AuthButton;
