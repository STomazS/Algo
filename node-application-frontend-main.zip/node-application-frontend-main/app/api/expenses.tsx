import 'dotenv/config'

const server = process.env.SERVER || 'http://localhost:3001/api/'
const route = `${server}expenses`

class ExpensesRoutes {

    static async addExpense(description: string, value: number, token: string) {
        const result = await fetch(`${route}/addexpense`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ description, value }) })

        return result
    }

    static async getExpenses(token: string){
        const result = await fetch(`${route}`, { method: 'GET', headers: { 'Authorization': `Bearer ${token}` }})

        return result
    }

    static async removeExpense(token: string, expenseId: string){
        const result = await fetch(`${route}/removeexpense`, {method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ id: expenseId })})

        return result
    }

    static async editExpense(token: string, expenseId: string, description: string, value: number){
        const result = await fetch(`${route}/editexpense`, {method: 'PUT', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ id: expenseId, description, value })})

        return result
    }

}


export default ExpensesRoutes