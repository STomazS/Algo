import 'dotenv/config'

const server = process.env.SERVER || 'http://localhost:3001/api/'
const route = `${server}users`

export interface User{
  id: string,
  email: string,
  name: string
}

class UserRoutes {
  static async getUsers(token: string | null) {
    if(token == null)
      return

    const result = await fetch(route, { method: 'GET', headers: { 'Authorization': `Bearer ${token}` } })

    const users: User[] = await result.json();

    return users
  }

  static async getUserInformation(token: string | null) {
    if (token == null)
      return

    const result = await fetch(`${route}/id`, { method: 'GET', headers: { 'Authorization': `Bearer ${token}` } })

    const user: User =  await result.json();

    return user
  }

  static async getUserWithEmail(email: string, token: string | null) {
    if (token == null)
      return

    const result = await fetch(`${route}/email/${email}`, { method: 'GET', headers: { 'Authorization': `Bearer ${token}` } })

    const user: User =  await result.json();

    return user
  }
}

export default UserRoutes

