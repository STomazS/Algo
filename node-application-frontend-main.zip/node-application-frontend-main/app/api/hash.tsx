import 'dotenv/config'

const server = process.env.SERVER || 'http://localhost:3001/api/'
const route = `${server}hash`

class HashRoutes{

    static async registerUser(name: string, email: string, password: string){
        const result = await fetch(`${route}/registeruser`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email, password}) })
    
        return result
    }
    
    static async login(email: string, password: string){
        const result = await fetch(`${route}/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password}) })
    
        return result
    }

    static async confirmAccount(email: string, code: string){
        const result = await fetch(`${route}/confirmaccount`, {method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, code })})

        return result
    }

}


export default HashRoutes