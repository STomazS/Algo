import React from 'react'
import ExpensesHandler from '../../components/ExpenseHandler'

const Expenses = () => {
  return (
    <>
      <div>
        <ExpensesHandler></ExpensesHandler>
      </div>
    </>
  )
}

export default Expenses