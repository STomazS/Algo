import React from 'react'
import GoBackButton from '../../components/GoBackButton';
import AllUsers from '../../components/AllUsers';

const UsersPage = () => {

  return (
    <div className='px-4 py-8'>
      <div>
        <GoBackButton></GoBackButton>
      </div>
      <h1 className='font-bold text-xl mx-auto w-40 pb-10'>Users</h1>
      <table className='table table-bordered mx-auto w-1/2'>
        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
          <tr>
            <th className='px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white'>
              Name
            </th>
            <th className='px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white'>
              Email
            </th>
          </tr>
        </thead>
        <AllUsers></AllUsers>
      </table>
    </div>
  )
}

export default UsersPage