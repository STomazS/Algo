import Link from 'next/link'
import React from 'react'
import LogoutButton from '../components/LogoutButton'
import UserInformation from '../components/UserInformation'

const HomePage = async () => {
    return (
        <div className='px-4 py-8'>
            <h1 className='text-2xl'>Welcome!</h1>
            <ul className='flex items-center flex-row'>
                <li className='ml-4 mt-4 text-center p-3 rounded-md w-24 bg-white text-black hover:bg-slate-200'>
                    <Link href="/home/users">Users</Link>
                </li>
                <li className='ml-8 mt-4 text-center p-3 rounded-md w-24 bg-white text-black hover:bg-slate-200'>
                    <Link href="/home/expenses">Expenses</Link>
                </li>
                <li>
                    <UserInformation></UserInformation>
                </li>
            </ul>

            <div className="text-center">
                <LogoutButton />
            </div>
        </div>
    )
}

export default HomePage