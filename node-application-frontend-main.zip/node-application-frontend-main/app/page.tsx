import AuthButton from "./components/AuthButton";
import { Path } from "./utils/path";

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100 flex flex-col justify-center items-center p-6">
      <h1 className="text-4xl font-bold text-center text-gray-800 mb-8">Welcome!</h1>

      <div className="flex flex-col items-center space-y-4">
        <AuthButton path={Path.LOGIN} />
        <AuthButton path={Path.REGISTER} />
        <AuthButton path={Path.CONFIRM_ACCOUNT} />
      </div>
    </main>
  );
}
